package com.example.syarief.clean;

import android.app.Activity;

/**
 * Created by Syarief on 05-Nov-17.
 */

public class item_list extends Activity {
}
